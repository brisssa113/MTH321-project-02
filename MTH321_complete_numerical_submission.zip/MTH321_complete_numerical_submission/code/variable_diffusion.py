"""Independent conservative variable-diffusion benchmarks on the unit square."""
import csv
import math
import time
from pathlib import Path

import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import cg, eigsh, spsolve
from skfem import Basis, BilinearForm, ElementTriP1, LinearForm, MeshTri, asm, condense
from skfem.helpers import dot, grad


def exact(x, y, case):
    if case == "smooth":
        return np.exp(x+y)
    # Unit potential drop with continuous flux through x=1/2.
    return np.where(x <= .5, x, .5 + (x-.5)/10) / .55


def forcing(x, y, case):
    return -(3+2*x)*np.exp(x+y) if case == "smooth" else np.zeros_like(x)


def coefficient(x, case):
    return 1+x if case == "smooth" else np.where(x < .5, 1., 10.)


def assemble_fdm(n, case, mean="physical"):
    h = 1/n
    m = n-1
    a = lil_matrix((m*m, m*m))
    b = np.empty(m*m)
    def index(i, j):
        return (j-1)*m+i-1
    for j in range(1, n):
        y = j*h
        for i in range(1, n):
            x = i*h
            k = index(i, j)
            b[k] = forcing(x, y, case)
            for di, dj in ((-1,0),(1,0),(0,-1),(0,1)):
                nx, ny = (i+di)*h, (j+dj)*h
                fx = x + di*h/2
                if case == "layered" and di and abs(fx-.5) < 1e-12:
                    face = 2/(1/1+1/10) if mean == "harmonic" else 5.5
                else:
                    face = float(coefficient(fx, case))
                c = face/h**2
                a[k,k] += c
                if 1 <= i+di < n and 1 <= j+dj < n:
                    a[k,index(i+di,j+dj)] -= c
                else:
                    b[k] += c*exact(nx, ny, case)
    return a.tocsr(), b


def assemble_fem(n, case):
    grid = np.linspace(0, 1, n+1)
    mesh = MeshTri.init_tensor(grid, grid)
    basis = Basis(mesh, ElementTriP1(), intorder=10)
    @BilinearForm
    def diffusion(u, v, w):
        return coefficient(w.x[0], case)*dot(grad(u), grad(v))
    @LinearForm
    def load(v, w):
        return forcing(w.x[0], w.x[1], case)*v
    a = asm(diffusion, basis).tocsr()
    b = asm(load, basis)
    known = exact(mesh.p[0], mesh.p[1], case)
    ac, bc, full, free = condense(a, b, x=known.copy(), D=mesh.boundary_nodes())
    return mesh, basis, ac.tocsr(), bc, full, free


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run(root: Path):
    out = root/"data"/"variable_diffusion"
    out.mkdir(parents=True, exist_ok=True)
    smooth = []
    for n in (8, 16, 32, 64):
        for method in ("FDM", "FEM"):
            start = time.perf_counter()
            if method == "FDM":
                a, b = assemble_fdm(n, "smooth")
            else:
                mesh, basis, a, b, full, free = assemble_fem(n, "smooth")
            assembly_s = time.perf_counter()-start
            start = time.perf_counter()
            u = spsolve(a.tocsc(), b)
            solve_s = time.perf_counter()-start
            if method == "FDM":
                xx, yy = np.meshgrid(np.arange(1,n)/n, np.arange(1,n)/n)
                target = exact(xx, yy, "smooth").ravel()
            else:
                full[free] = u
                target = exact(mesh.p[0], mesh.p[1], "smooth")[free]
            error = float(np.max(np.abs(u-target)))
            count = [0]
            def callback(_):
                count[0] += 1
            precond = __import__("scipy").sparse.diags(1/a.diagonal())
            ucg, status = cg(a, b, M=precond, rtol=1e-10, atol=0, callback=callback)
            assert status == 0
            row = dict(case="smooth", method=method, N=n, h=1/n,
                       dof=len(b), nnz=a.nnz, error_inf=error,
                       residual_inf=float(np.max(np.abs(b-a@u))),
                       scaled_residual=float(np.max(np.abs(b-a@u)/np.maximum(np.asarray(abs(a)@abs(u)+abs(b)).ravel(),1e-300))),
                       cg_iterations=count[0], cg_direct_difference_inf=float(np.max(np.abs(ucg-u))),
                       dmp_offdiagonal_nonpositive=bool(np.max((a - __import__("scipy").sparse.diags(a.diagonal())).data) <= 1e-12),
                       assembly_s=assembly_s, solve_s=solve_s)
            if n <= 32:
                row["condition_2"] = float(eigsh(a,k=1,which="LM",return_eigenvectors=False)[0]/
                                           eigsh(a,k=1,which="SM",return_eigenvectors=False)[0])
            else:
                row["condition_2"] = ""
            smooth.append(row)
    for method in ("FDM", "FEM"):
        sub = [r for r in smooth if r["method"] == method]
        for i,r in enumerate(sub):
            r["order"] = "" if i == 0 else math.log(sub[i-1]["error_inf"]/r["error_inf"],2)
    write_csv(out/"smooth.csv", smooth)

    layered = []
    # Odd N puts the material interface exactly on a vertical face.
    for n in (7, 15, 31, 63):
        for mean in ("harmonic", "arithmetic"):
            a,b = assemble_fdm(n,"layered",mean)
            u = spsolve(a.tocsc(),b)
            xx, yy = np.meshgrid(np.arange(1,n)/n,np.arange(1,n)/n)
            err = float(np.max(np.abs(u-exact(xx,yy,"layered").ravel())))
            j = n//2
            left = u[j*(n-1)+j-1]
            right = u[j*(n-1)+j]
            face = 2/(1+1/10) if mean == "harmonic" else 5.5
            flux = face*(right-left)*n
            count = [0]
            def callback(_):
                count[0] += 1
            ucg, status = cg(a,b,M=__import__("scipy").sparse.diags(1/a.diagonal()),
                             rtol=1e-10,atol=0,callback=callback)
            assert status == 0
            layered.append(dict(N=n, mean=mean, dof=len(b), error_inf=err,
                                interface_flux=flux, flux_error=abs(flux-1/.55),
                                residual_inf=float(np.max(np.abs(b-a@u))),
                                scaled_residual=float(np.max(np.abs(b-a@u)/np.maximum(np.asarray(abs(a)@abs(u)+abs(b)).ravel(),1e-300))),
                                cg_iterations=count[0], cg_direct_difference_inf=float(np.max(np.abs(ucg-u))),
                                dmp_offdiagonal_nonpositive=bool(np.max((a-__import__("scipy").sparse.diags(a.diagonal())).data)<=1e-12),
                                condition_2=(float(eigsh(a,k=1,which="LM",return_eigenvectors=False)[0]/
                                                   eigsh(a,k=1,which="SM",return_eigenvectors=False)[0]) if n<=31 else "")))
    write_csv(out/"layered.csv",layered)
    text = [r"\section{Variable diffusion benchmark}",
            r"\label{sec:variable-diffusion}",
            r"This is a separate all-Dirichlet benchmark for $-\nabla\cdot(a\nabla u)=f$ on $(0,1)^2$; it does not change the mixed-boundary model. For the smooth case $a=1+x$, $u_*=e^{x+y}$ and $f=-(3+2x)e^{x+y}$. The FDM uses one shared coefficient per face in a conservative five-point flux balance. The P1 FEM assembles $\int a\nabla u_h\cdot\nabla v_h$ on the same square grid split into triangles. Exact boundary values are imposed in both methods.",
            r"\begin{table}[htbp]\centering\small\begin{tabular}{llrrr}\toprule Method & $N$ & nodal $L^\infty$ error & order & CG steps\\\midrule"]
    for r in smooth:
        order = "--" if r["order"] == "" else f'{r["order"]:.2f}'
        text.append(f'{r["method"]} & {r["N"]} & {r["error_inf"]:.3g} & {order} & {r["cg_iterations"]} \\\\')
    text += [r"\bottomrule\end{tabular}\caption{Variable smooth coefficient, matched mesh and nodal error. Full residuals, timings, nonzeros and condition estimates are in \texttt{data/variable\_diffusion/smooth.csv}.}\end{table}",
             r"For a separate layered material, $a=1$ for $x<1/2$ and $a=10$ for $x>1/2$. The exact one-dimensional solution is $u_*(x)=[\min(x,1/2)+\max(x-1/2,0)/10]/0.55$, with constant flux $1/0.55$. Odd $N$ places the interface on a vertical face. Harmonic and arithmetic face means are compared on exactly the same grids; no FEM claim is made for this discontinuous case.",
             r"\begin{table}[htbp]\centering\small\begin{tabular}{llrr}\toprule $N$ & face mean & maximum error & interface flux error\\\midrule"]
    for r in layered:
        text.append(f'{r["N"]} & {r["mean"]} & {r["error_inf"]:.3g} & {r["flux_error"]:.3g} \\\\')
    text += [r"\bottomrule\end{tabular}\caption{Layered interface benchmark; complete values are in \texttt{data/variable\_diffusion/layered.csv}.}\end{table}",
             r"All assembled interior matrices have nonpositive off-diagonal entries and a positive Dirichlet boundary contribution, giving the discrete maximum-principle sign structure. The CSV records this check, the componentwise scaled residual, CG iteration count and direct--CG difference for each case. Estimated spectral condition numbers are reported through $N=32$ for smooth data and $N=31$ for layered data. They are properties of these specific unpreconditioned matrices and coefficient contrast; no extrapolated complexity claim is made."]
    (root/"report"/"variable_diffusion.tex").write_text("\n".join(text)+"\n",encoding="utf-8")
    return smooth,layered
