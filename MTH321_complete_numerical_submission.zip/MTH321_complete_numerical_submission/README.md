# MTH321 Project 2 numerical experiments

This package contains the mixed-boundary Poisson implementation and its numerical evidence, plus separate depth and variable-diffusion comparisons. The full group report remains in Overleaf. The main experiments cover both right-edge closures with Neumann and Robin data, refinement through N=512, matrix and energy checks, direct/GMRES/CG comparisons, an independent FEM check, and a pure-Neumann extension. The added all-Dirichlet benchmarks compare sparse direct with Jacobi, FDM with P1 FEM, and smooth with corner-singular solutions on an L-shaped domain.

## Reproduce

Use Python 3.13 from this folder:

```text
python -m pip install -r requirements.txt
python -m unittest discover -s code/tests -v
python code/run_all.py
```

`code/run_all.py` is the **only execution entry point**. It regenerates the CSV files, plots, report tables `report/depth_extension.tex` and `report/variable_diffusion.tex`. The 18 tests are a separate verification command. The saved run used Python 3.13.15 and the versions in `requirements.txt`; exact environments are in `data/run_metadata.json` and `data/depth_extension/run_metadata.json`. Timings vary across machines and runs.

## Files

| Path | Contents |
| --- | --- |
| `code/run_all.py` | Single entry point and CSV-to-LaTeX conversion |
| `code/models.py`, `experiments.py`, `reporting.py`, `make_figures.py` | Mixed-boundary model, experiments and outputs |
| `code/fem_oracle.py`, `pure_neumann.py` | Independent FEM and pure-Neumann checks |
| `code/depth_benchmarks.py` | Direct/Jacobi, square FDM/FEM and L-shaped experiments |
| `code/tests/` | 16 automated tests |
| `data/` | Mixed-boundary CSV files and run metadata |
| `data/depth_extension/` | Three new CSV tables and separate run metadata |
| `figures/` | Original and additional plots |
| `generated/` | Report-ready LaTeX tables and `raw_tables/` conversions of every CSV |
| `report/` | Implementation, experiments and supplementary depth LaTeX sections |

## Overleaf integration

The report fragments are not standalone documents. The existing Overleaf project uses `\input{depth_extension}` after `\input{experiments}` and before conclusions. Copy `report/depth_extension.tex` to the Overleaf root, the new figures into `figures/`, and the depth CSVs into `data/depth_extension/`. The square all-Dirichlet and L-shaped results are separate benchmarks; do not substitute them into the original mixed-boundary FO/G tables. The L-shaped singular solution is continuous but nonsmooth, not discontinuous.

## Further checks

Variable diffusion is a separate all-Dirichlet benchmark: smooth a=1+x uses matched FDM/FEM meshes, while the discontinuous two-layer case compares harmonic and arithmetic face means on an interface-aligned FDM grid. Data: data/variable_diffusion/. The L-shaped study also retains lshape_quadrature.csv and lshape_solver_check.csv, plus two mesh images. The order-12 to order-19 singular energy error changes by about 0.22%, so the convergence trend is more reliable than all printed digits. The FEM theory paragraph is report/lshape_theory.tex and must be placed next to the L-shaped section in the Overleaf report.

